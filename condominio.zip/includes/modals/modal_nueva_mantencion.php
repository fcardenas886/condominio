<div class="modal fade" id="modalNuevaMantencion" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content border-0 shadow-lg">
            <form action="modulos/guardar_mantencion.php" method="POST" id="formMantencion">
                <div class="modal-header bg-primary text-white">
                    <h5 class="modal-title">
                        <i class="bi bi-tools me-2"></i>Registrar Mantención
                    </h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                
                <div class="modal-body">
                    <div class="row g-3">
                        
                        <div class="col-12">
                            <label class="small fw-bold text-muted text-uppercase">Ubicación / Destino:</label>
                            <select name="id_casa" id="id_casa_selector" class="form-select border-primary" required>
                                <option value="0">🏢 ÁREAS COMUNES (General)</option>
                                <optgroup label="Casas Individuales">
                                    <?php foreach($casas as $c): ?>
                                        <option value="<?php echo $c['id_casa']; ?>">
                                            Casa N° <?php echo htmlspecialchars($c['numero_casa']); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </optgroup>
                            </select>
                        </div>

                        <div class="col-12">
                            <label class="small fw-bold text-muted text-uppercase">Descripción del Trabajo:</label>
                            <textarea name="descripcion" class="form-control" rows="2" 
                                      placeholder="Ej: Reparación motor portón o filtración baño" required></textarea>
                        </div>

                        <div class="col-12">
                            <label class="small fw-bold text-muted text-uppercase">Proveedor encargado:</label>
                            <select name="id_proveedor" class="form-select" required>
                                <option value="">Seleccionar proveedor...</option>
                                <?php foreach($proveedores as $p): ?>
                                    <option value="<?php echo $p['id_proveedor']; ?>">
                                        <?php echo htmlspecialchars($p['nombre']); ?>
                                    </button>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <div class="col-6">
                            <label class="small fw-bold text-muted text-uppercase">Monto Pagado:</label>
                            <div class="input-group">
                                <span class="input-group-text bg-light">$</span>
                                <input type="number" name="monto_pagado" class="form-control" placeholder="0" required>
                            </div>
                        </div>

                        <div class="col-6">
                            <label class="small fw-bold text-muted text-uppercase">Fecha del Servicio:</label>
                            <input type="date" name="fecha" class="form-control" 
                                   value="<?php echo date('Y-m-d'); ?>" required>
                        </div>

                        <div class="col-12" id="seccion_cobro" style="display: none;">
                            <div class="form-check form-switch p-3 border rounded bg-light border-warning">
                                <input class="form-check-input ms-0" type="checkbox" name="cobrar_a_arrendatario" value="1" id="checkCobro">
                                <label class="form-check-label small fw-bold ms-2 text-danger" for="checkCobro">
                                    <i class="bi bi-exclamation-triangle-fill me-1"></i> ¿Cobrar este monto al Arrendatario?
                                </label>
                            </div>
                            <div class="form-text text-muted mt-1 small">
                                * Si es una reparación por mal uso, marque esta opción.
                            </div>
                        </div>

                    </div>
                </div>

                <div class="modal-footer bg-light">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                    <button type="submit" class="btn btn-primary px-4 shadow-sm">
                        <i class="bi bi-save me-1"></i> Guardar Registro
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const selectorCasa = document.getElementById('id_casa_selector');
    const seccionCobro = document.getElementById('seccion_cobro');
    const checkCobro = document.getElementById('checkCobro');

    // Función para mostrar/ocultar el cobro al arrendatario
    selectorCasa.addEventListener('change', function() {
        if (this.value != "0") {
            // Si es una casa específica, mostramos el switch de cobro
            seccionCobro.style.display = 'block';
        } else {
            // Si es General, ocultamos y nos aseguramos de que el check esté apagado
            seccionCobro.style.display = 'none';
            checkCobro.checked = false;
        }
    });
});
</script>