<?php
include '../includes/conexion.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $descripcion = $_POST['descripcion'];
    $id_casa = $_POST['id_casa'];
    $id_proveedor = $_POST['id_proveedor'];
    $monto = $_POST['monto_pagado'];
    $fecha = $_POST['fecha'];
    // Si el checkbox no se marca, mandamos 0, si se marca mandamos 1
    $cobrar = isset($_POST['cobrar_a_arrendatario']) ? 1 : 0;

    try {
        $sql = "INSERT INTO mantenciones (descripcion, id_casa, id_proveedor, monto_pagado, cobrar_a_arrendatario, fecha) 
                VALUES (?, ?, ?, ?, ?, ?)";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$descripcion, $id_casa, $id_proveedor, $monto, $cobrar, $fecha]);

        header("Location: ../gestion_mantenciones.php?res=ok");
    } catch (PDOException $e) {
        header("Location: ../gestion_mantenciones.php?error=" . urlencode($e->getMessage()));
    }
    exit();
}